//
//  FootView.m
//  collectionView测试
//
//  Created by laidongling on 16/8/25.
//  Copyright © 2016年 laidongling. All rights reserved.
//

#import "FootView.h"

@implementation FootView

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
+ (instancetype)viewForXib
{
    return [[NSBundle mainBundle]loadNibNamed:NSStringFromClass(self) owner:nil options:nil].lastObject;
}


@end
