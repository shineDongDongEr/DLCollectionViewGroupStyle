//
//  LDLItem.m
//  collectionView测试
//
//  Created by winter on 16/8/24.
//  Copyright © 2016年 laidongling. All rights reserved.
//

#import "LDLItem.h"
@interface LDLItem()
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;
@property (weak, nonatomic) IBOutlet UILabel *loverLabel;

@end
@implementation LDLItem

- (void)awakeFromNib {
    [super awakeFromNib];
    self.contentView.backgroundColor = [UIColor brownColor];
    
}

+ (instancetype)viewForXib
{

    return [[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil].lastObject;
}
-(void)setName:(NSString *)name
{
    _name = name;
    self.loverLabel.text = name;

}

- (void)setNumber:(NSInteger)number
{

    _number = number;
    self.numberLabel.text = [NSString stringWithFormat:@"%ld个",(long)number];

}

-(void)setLDLCellModel:(LDLModel *)LDLCellModel
{
    _LDLCellModel = LDLCellModel;
    self.numberLabel.text = LDLCellModel.name;
    self.loverLabel.text = [NSString stringWithFormat:@"%ld",(long)LDLCellModel.number];
    


}
@end
