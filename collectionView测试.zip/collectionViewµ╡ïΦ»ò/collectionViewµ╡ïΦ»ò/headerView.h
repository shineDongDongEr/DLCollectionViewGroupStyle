//
//  headerView.h
//  collectionView测试
//
//  Created by laidongling on 16/8/25.
//  Copyright © 2016年 laidongling. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface headerView : UICollectionReusableView

@property (weak, nonatomic) IBOutlet UILabel *headerLabel;
+ (instancetype)viewForXib;
@end
