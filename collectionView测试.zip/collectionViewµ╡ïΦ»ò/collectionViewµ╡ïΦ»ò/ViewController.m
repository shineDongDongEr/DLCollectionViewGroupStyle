//
//  ViewController.m
//  collectionView测试
//
//  Created by winter on 16/8/24.
//  Copyright © 2016年 laidongling. All rights reserved.
//

#import "ViewController.h"
#import "LDLModel.h"
#import "LDLItem.h"
#import "headerView.h"
#import "FootView.h"

#define LDLScreenW [UIScreen mainScreen].bounds.size.width
#define LDLScreenH [UIScreen mainScreen].bounds.size.height

static NSString *const ID = @"cell";
static NSString *const headerID = @"123";
static NSString *const footerID = @"321";

@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (nonatomic ,strong) UICollectionView *collectionview;
@property (nonatomic ,strong) NSArray <LDLModel *>*arrayM;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createCollectionView];
    [self.collectionview registerNib:[UINib nibWithNibName:@"LDLItem" bundle:nil] forCellWithReuseIdentifier:ID];
    [self.collectionview registerNib:[UINib nibWithNibName:@"headerView" bundle:nil] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:headerID];
     [self.collectionview registerNib:[UINib nibWithNibName:@"FootView" bundle:nil] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:footerID];
}

- (void)createCollectionView
{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    //item的尺寸;
    layout.itemSize = CGSizeMake((LDLScreenW-1) / 4.0f, (LDLScreenW-1) / 4.0f);
    NSLog(@"%f",(LDLScreenW-1) / 4.0f);
    //item上下行距;
    layout.minimumLineSpacing = 1;
    //每组的items与其组头部和底部的距离，上左下右，一般只设置上下;
//    layout.sectionInset = UIEdgeInsetsMake(10, 0, 10, 0);
    //*************************************************************
    //iOS9中的collectionView，当设置了头部，底部后，还没有提供相关属性用于设置底部和头部之间的组与组之间的距离，此处采用自定headerview中加空白uivi
    //实现。
    //*************************************************************
    //item左右行距;
    layout.minimumInteritemSpacing = 0.0f;
    //滑动底部条固定在可视底部;
    layout.sectionFootersPinToVisibleBounds = YES;
    //互动头部条固定在可视头部;
    layout.sectionHeadersPinToVisibleBounds = YES;
    
    UICollectionView *collectionView = [[UICollectionView alloc]initWithFrame:self.view.bounds collectionViewLayout:layout];
    collectionView.backgroundColor = [UIColor clearColor];
    collectionView.delegate = self;
    collectionView.dataSource = self;
    _collectionview = collectionView;
    
    [self.view addSubview: collectionView];
    
}
#pragma mark - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 3;

}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 8;
    
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    LDLItem *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    cell.LDLCellModel = self.arrayM[indexPath.row];
    cell.name = @"WS";
    cell.contentView.backgroundColor = [UIColor purpleColor];
    switch (indexPath.section)
    {
        case 0:
             cell.number = indexPath.row + 1 ;
            break;
        case 1:
            cell.number = indexPath.row + 9 ;
            break;
        case 2:
            cell.number = indexPath.row + 17 ;
            break;
        
        default:
            break;
    }
    return cell;


}
#pragma mark - UICollectionViewDelegate
//自定义头部和底部;
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        headerView *heaV = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:headerID forIndexPath:indexPath];
        
        switch (indexPath.section) {
            case 0:
               heaV.headerLabel.text = @"头部 : I want to own ";
                break;
            case 1:
                heaV.headerLabel.text = @"头部 : If there  are  other ";
                break;
            case 2:
                heaV.headerLabel.text = @"头部 :  others again  are  better ";
                break;
            default:
                break;
        }
        return heaV;
        
    }
    if ([kind isEqualToString:UICollectionElementKindSectionFooter]) {
        FootView *footerview = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:footerID forIndexPath:indexPath];
        switch (indexPath.section) {
            case 0:
                footerview.footerLabel.text = @"底部 : but  no   anything  ...😭😭😭";
                break;
            case 1:
                footerview.footerLabel.text = @"底部 : I will  be  happy  a litle  😃";
                break;
            case 2:
                footerview.footerLabel.text = @"底部 : I  feel   very  good 😄😄😄";
                break;
            default:
                break;
        }
        return footerview;

        
    }
    return  nil;

}
//返回底部高度;
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section
{
    return CGSizeMake(LDLScreenW, 44);

}

//返回头部高度;
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{

    return  CGSizeMake(LDLScreenW, 44);
}


@end
