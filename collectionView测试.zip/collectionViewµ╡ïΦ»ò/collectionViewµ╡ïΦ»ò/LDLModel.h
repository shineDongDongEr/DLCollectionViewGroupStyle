//
//  LDLModel.h
//  collectionView测试
//
//  Created by winter on 16/8/24.
//  Copyright © 2016年 laidongling. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LDLModel : NSObject
@property(nonatomic,copy)NSString *name;
@property(nonatomic,assign)NSInteger number;

@end
