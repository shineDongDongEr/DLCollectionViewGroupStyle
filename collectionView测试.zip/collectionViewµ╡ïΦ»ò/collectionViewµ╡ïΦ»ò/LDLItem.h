//
//  LDLItem.h
//  collectionView测试
//
//  Created by winter on 16/8/24.
//  Copyright © 2016年 laidongling. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LDLModel.h"

@interface LDLItem : UICollectionViewCell
@property(nonatomic,copy)NSString *name;
@property(nonatomic,assign)NSInteger number;

@property (nonatomic ,strong) LDLModel *LDLCellModel;

+ (instancetype)viewForXib;

@end
